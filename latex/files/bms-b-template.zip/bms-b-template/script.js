requirejs(['bmotion.template'], function (bms) {
    // Put your code here
});