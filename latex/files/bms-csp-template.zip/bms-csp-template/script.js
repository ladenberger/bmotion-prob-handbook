requirejs(['bmotion.vis'], function () {
});