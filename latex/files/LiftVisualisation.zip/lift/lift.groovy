import de.bms.observer.BMotionObserver
import de.prob.statespace.Trace

// Groovy Transformer
/*transform("#door") {
    set "fill", { (bms.eval("door_open").value == "TRUE") ? "white" : "lightgray" }
    set "y", {
        switch (bms.eval("cur_floor").value) {
            case "-1": "275"
                break
            case "0": "175"
                break
            case "1": "60"
                break
            default: "275"
        }
    }
    register(bms)
}

transform("#txt_cur_floor") {
    set "text", { bms.eval("cur_floor").value }
    register(bms)
}*/

def customObserver = [
    apply: {
        System.out.println("Triggering custom observer")
    }
] as BMotionObserver
bms.registerObserver(customObserver)

bms.registerMethod("openCloseDoor", {
    def Trace t = bms.getTrace()
    def Trace newTrace = executeEvent(t, "open_door", []) ?: executeEvent(t, "close_door", [])
    if (newTrace != null) {
        animations.traceChange(newTrace)
        return [newState: newTrace.getCurrentState().id]
    }
})

def Trace executeEvent(t, name, pred) {
    try {
        t.execute(name, pred)
    } catch (IllegalArgumentException e) {
        null
    }
}
