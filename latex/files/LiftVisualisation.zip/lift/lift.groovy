bms.registerMethod("testMethod", { data -> return [some: "newdata"] })
