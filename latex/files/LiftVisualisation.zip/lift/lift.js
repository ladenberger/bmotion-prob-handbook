require(['prob'], function (prob) {

    $("text[data-floor]").executeEvent({
        events: [
            {
                name: "push_call_button", predicate: function (origin) {
                return "b=" + $(origin).attr("data-floor")
            }
            },
            {
                name: "push_inside_button", predicate: function (origin) {
                return "b=" + $(origin).attr("data-floor")
            }
            }
        ]
    });

    $("#txt_cur_floor").observe("formula", {
        formulas: ["cur_floor"],
        trigger: function (origin, data) {
            origin.text(data.values[0].value)
        }
    });

    $("#door").observe("method", {
        name: "testMethod",
        data: {
            some: "data"
        },
        trigger: function (origin, data) {
            console.log(data)
        }
    })

    $("#door").executeEvent({
        events: [{name: "close_door"}, {name: "open_door"}]
    }).observe("formula", {
        formulas: ["cur_floor", "door_open"],
        trigger: function (origin, data) {
            var val = data.values
            val[1].value === "TRUE" ? origin.attr("fill", "white") : origin.attr("fill", "lightgray");
            switch (val[0].value) {
                case "0":
                    origin.attr("y", "175");
                    break;
                case "1":
                    origin.attr("y", "60");
                    break;
                case "-1":
                    origin.attr("y", "275");
                    break;
            }
        }
    });

});
