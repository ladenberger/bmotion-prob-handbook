require(['prob'], function (prob) {

    $("text[data-floor]").executeEvent({
        events: [
            {
                name: "push_call_button", predicate: function (origin) {
                return "b=" + origin.attr("data-floor")
            }
            },
            {
                name: "push_inside_button", predicate: function (origin) {
                return "b=" + origin.attr("data-floor")
            }
            }
        ]
    });

    $("#txt_cur_floor").observe("formula", {
        formulas: ["cur_floor"],
        trigger: function (origin, res) {
            origin.text(res[0])
        }
    });

    $("#door").observe("method", {
        name: "testMethod",
        data: {
            some: "data"
        },
        trigger: function (origin, res) {
            console.log(res)
        }
    })

    $("#door").executeEvent({
        events: [{name: "close_door"}, {name: "open_door"}]
    }).observe("formula", {
        formulas: ["cur_floor", "door_open"],
        trigger: function (origin, res) {
            res[1] === "TRUE" ? origin.attr("fill", "white") : origin.attr("fill", "lightgray");
            switch (res[0]) {
                case "0":
                    origin.attr("y", "175");
                    break;
                case "1":
                    origin.attr("y", "60");
                    break;
                case "-1":
                    origin.attr("y", "275");
                    break;
            }
        }
    });

});
