require.config({
    paths: {
        'prob': '/bms/libs/prob/prob'
    }
});
define(["require", "prob"], function (require) {

    var bms = require('bmotion')

    bms.socket.on('initSvg', function () {

        $('text[data-floor]').each(function () {
            $(this).click(function () {
                bms.executeEvent('push_call_button', {
                    predicate: 'b=' + $(this).attr('data-floor'),
                    callback: function (data) {
                        console.log('Callback: ' + data)
                    }
                })
            }).css('cursor', 'pointer')
        });


        $("#door").click(function () {
            bms.callMethod("openCloseDoor", {
                callback: function (data) {
                    console.log('Callback: ' + data)
                }
            })
        }).css('cursor', 'pointer')

    });

});
