require.config({
    paths: {
        'prob': '/bms/libs/prob/prob'
    }
});
define(["require", "prob"], function (require) {

    var bms = require('bmotion')

    bms.socket.on('initSvg', function () {

        $("text[data-floor]").each(function () {
            var p = "b=" + $(this).attr("data-floor")
            $(this).executeEvent({
                events: [
                    {name: "push_call_button", predicate: p},
                    {name: "push_inside_button", predicate: p}
                ],
                callback: function (origin, data) {
                }
            });
        });

        bms.observe({
            expressions: ["cur_floor"],
            trigger: function (data) {
                $("#txt_cur_floor").html(data.values[0].value)
            }
        });

        $("#door").executeEvent({
            events: [{name: "close_door"}, {name: "open_door"}],
            callback: function (origin, data) {
            }
        }).observe({
            expressions: ["cur_floor", "door_open"],
            trigger: function (origin, data) {
                var values = data.values
                switch (values[0].value) {
                    case "-1": origin.attr("y", "275"); break
                    case "0": origin.attr("y", "175"); break
                    case "1": origin.attr("y", "60"); break
                }
                values[1].value == "TRUE" ? origin.attr("fill", "white") : origin.attr("fill", "lightgray")
            }
        }).observe({
            cause: "ModelInitialised",
            trigger: function () {
                console.log("Model initialised")
            }
        });

    });

});
